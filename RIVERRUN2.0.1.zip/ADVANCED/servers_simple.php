<?php



function get_client_ip() {
    $ipaddress = '';
    if (getenv('HTTP_CLIENT_IP'))
        $ipaddress = getenv('HTTP_CLIENT_IP');
    else if(getenv('HTTP_X_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
    else if(getenv('HTTP_X_FORWARDED'))
        $ipaddress = getenv('HTTP_X_FORWARDED');
    else if(getenv('HTTP_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_FORWARDED_FOR');
    else if(getenv('HTTP_FORWARDED'))
       $ipaddress = getenv('HTTP_FORWARDED');
    else if(getenv('REMOTE_ADDR'))
        $ipaddress = getenv('REMOTE_ADDR');
    else
        $ipaddress = 'UNKNOWN';
    return $ipaddress;
}

function checkOnline($domain) {
   $curlInit = curl_init($domain);
   curl_setopt($curlInit,CURLOPT_CONNECTTIMEOUT,10);
   curl_setopt($curlInit,CURLOPT_HEADER,true);
   curl_setopt($curlInit,CURLOPT_NOBODY,true);
   curl_setopt($curlInit,CURLOPT_RETURNTRANSFER,true);

   //get answer
   $response = curl_exec($curlInit);

   curl_close($curlInit);
   if ($response) return true;
   return false;
}

$user_ip = get_client_ip();

$user_ip = str_replace(":", "_", $user_ip);

$user_ip = $user_ip . ".txt";

$minute = date("i");

$hour = date("G");

$day = date("d");

$month = date("m");

$year = date("y");




$dir = "SERVERS";

if(!file_exists("SERVERS/$year/$month/$day/$user_ip")){


mkdir("$dir/$year", 0700);

mkdir("$dir/$year/$month", 0700);

mkdir("$dir/$year/$month/$day", 0700);




$fp3 = fopen("$dir/$year/$month/$day/$user_ip", "w");

fclose($fp3);



}

$user_ip = get_client_ip();


echo "<table width='100%'><tr style='background-color: #AAAAAA;'><td> HOST </td><td> 80 </td><td> 8080 </td><td> 8000</td></tr>";

$search = "";

$x = 0;


foreach (glob("SERVERS/$search/*") as $file){


foreach (glob("$file/*") as $file2){


foreach (glob("$file2/*") as $file3){
echo $file3 . "</br>";


foreach (glob("$file3/*") as $file4){
$exp = explode("/", $file4);

$files = $exp[5];


$i = 0;

$host = $files;

$host = substr($host, 0, -4);

$host =  str_replace("_", ":", $host);


$port;

$available;

$page = "";

$host_check;

while ($i <= 2){

switch ($i) {
    case "0":
        $port = "80";
        break;
    case "1":
        $port = "8080";
        break;
    case "2":
        $port = "8000";
        break;
}

$hosted = "";
$hosted = $host . ':' . $port;

if(checkOnline($hosted)) {$available[$i] = "<a href='$hosted' target='_blank'>yes</a>"; $page = "<a href='$hosted' target='_blank'>$hosted</a>"; }else{$available[$i] = "no";}

$i++;
}

//echo $host , $available[0] . $available[1] . $available[2];


echo "<tr><td> $page </td><td> $available[0] </td><td> $available[1]</td><td> $available[2]</td></tr>";


$x++;
if ($x > 100){die;}
}

}

}

}



echo "</table>";
echo "</br>results : " . $x;







?>