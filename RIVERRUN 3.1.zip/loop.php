<?php

for ($x = 1; $x < 500; $x++){

echo  'input type="text" id="' . $x . '" name="tag' . $x . '"></br>';


}



?>
