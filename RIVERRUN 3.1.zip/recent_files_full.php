﻿<?php error_reporting(0); ?>

<html>
<head>

<link rel="stylesheet" type="text/css" href="default.css">

</head>

<body>

<?php



include ("riverrun.php");

$x = 0;


foreach (glob("RECENT/$search/*") as $file){
//echo $file . "</br>";


foreach (glob("$file/*") as $file2){
//echo $file2 . "</br>";


foreach (glob("$file2/*") as $file3){
echo $file3 . "</br>";


foreach (glob("$file3/*") as $file4){
$exp = explode("/", $file4);

$files = $exp[5];


$filesize = filesize("FILES/$files");
$filesize = file_size_readable($filesize);

    $extension = substr($files, -3);

    if ($extension == "png" || $extension == "jpg" || $extension == "gif" || $extension == "jpeg"){

    echo "<a href='FILES/$files'><img src='FILES/$files' alt='$files'></a> ";

    } elseif ($extension == "mp4"){

    echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow/file_extension_mp4.png' alt='$files'></a> ";	
  
    } else{


if ($extension == "mp3"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow/ilike.png' alt='$files'></a> ";} 
if ($extension == "3gp"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_3gp.png'></a>";}
if ($extension == "ace"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_ace.png'></a>";}
if ($extension == "aif"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_aif.png'></a>";}
if ($extension == "amr"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_amr.png'></a>";}
if ($extension == "asf"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_asf.png'></a>";}
if ($extension == "asx"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_asx.png'></a>";}
if ($extension == "bat"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_bat.png'></a>";}
if ($extension == "bin"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_bin.png'></a>";}
if ($extension == "bmp"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_bmp.png'></a>";}
if ($extension == "bup"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_bup.png'></a>";}
if ($extension == "cab"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_cab.png'></a>";}
if ($extension == "cbr"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_cbr.png'></a>";}
if ($extension == "cda"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_cda.png'></a>";}
if ($extension == "cdl"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_cdl.png'></a>";}
if ($extension == "cdr"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_cdr.png'></a>";}
if ($extension == "chm"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_chm.png'></a>";}
if ($extension == "dat"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_dat.png'></a>";}
if ($extension == "dll"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_dll.png'></a>";}
if ($extension == "dmg"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_dmg.png'></a>";}
if ($extension == "doc"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_doc.png'></a>";}
if ($extension == "dss"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_dss.png'></a>";}
if ($extension == "dvf"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_dvf.png'></a>";}
if ($extension == "dwg"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_dwg.png'></a>";}
if ($extension == "eml"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_eml.png'></a>";}
if ($extension == "eps"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_eps.png'></a>";}
if ($extension == "exe"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_exe.png'></a>";}
if ($extension == "fla"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_fla.png'></a>";}
if ($extension == "flv"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_flv.png'></a>";}
if ($extension == "gif"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_gif.png'></a>";}
if ($extension == "gz"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_gz.png'></a>";}
if ($extension == "hqx"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_hqx.png'></a>";}
if ($extension == "htm"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_htm.png'></a>";}
if ($extension == "html"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_html.png'></a>";}
if ($extension == "ifo"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_ifo.png'></a>";}
if ($extension == "iso"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_iso.png'></a>";}
if ($extension == "jar"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_jar.png'></a>";}
if ($extension == "lnk"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_lnk.png'></a>";}
if ($extension == "log"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_log.png'></a>";}
if ($extension == "m4a"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_m4a.png'></a>";}
if ($extension == "m4b"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_m4b.png'></a>";}
if ($extension == "m4p"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_m4p.png'></a>";}
if ($extension == "m4v"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_m4v.png'></a>";}
if ($extension == "mcd"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_mcd.png'></a>";}
if ($extension == "mdb"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_mdb.png'></a>";}
if ($extension == "mid"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_mid.png'></a>";}
if ($extension == "mov"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_mov.png'></a>";}
if ($extension == "mp2"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_mp2.png'></a>";}
if ($extension == "mp4"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_mp4.png'></a>";}
if ($extension == "mpg"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_mpg.png'></a>";}
if ($extension == "msi"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_msi.png'></a>";}
if ($extension == "ogg"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_ogg.png'></a>";}
if ($extension == "pdf"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_pdf.png'></a>";}
if ($extension == "pps"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_pps.png'></a>";}
if ($extension == "ps"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_ps.png'></a>";}
if ($extension == "psd"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_psd.png'></a>";}
if ($extension == "pst"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_pst.png'></a>";}
if ($extension == "ptb"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_ptb.png'></a>";}
if ($extension == "pub"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_pub.png'></a>";}
if ($extension == "qbb"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_qbb.png'></a>";}
if ($extension == "qbw"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_qbw.png'></a>";}
if ($extension == "qxd"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_qxd.png'></a>";}
if ($extension == "ram"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_ram.png'></a>";}
if ($extension == "rar"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_rar.png'></a>";}
if ($extension == "rm"){echo "<a href='FILES/$files'>i<mg src='TEMPLATES/fatcow_ext/file_extension_rm.png'></a>";}
if ($extension == "rtf"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_rtf.png'></a>";}
if ($extension == "sea"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_sea.png'></a>";}
if ($extension == "ses"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_ses.png'></a>";}
if ($extension == "sit"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_sit.png'></a>";}
if ($extension == "swf"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_swf.png'></a>";}
if ($extension == "tgz"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_tgz.png'></a>";}
if ($extension == "thm"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_thm.png'></a>";}
if ($extension == "tif"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_tif.png'></a>";}
if ($extension == "tmp"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_tmp.png'></a>";}
if ($extension == "ttf"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_ttf.png'></a>";}
if ($extension == "txt"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_txt.png'></a>";}
if ($extension == "vcd"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_vcd.png'></a>";}
if ($extension == "vob"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_vob.png'></a>";}
if ($extension == "wav"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_wav.png'></a>";}
if ($extension == "wma"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_wma.png'></a>";}
if ($extension == "wmv"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_wmv.png'></a>";}
if ($extension == "wps"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_wps.png'></a>";}
if ($extension == "xls"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_xls.png'></a>";}
if ($extension == "xpi"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_xpi.png'></a>";}
if ($extension == "zip"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_zip.png'></a>";}

$extension = substr($files, -2);

if ($extension == "7z"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_7z.png'></a>";}
if ($extension == "ai"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_ai.png'></a>";}
if ($extension == "ss"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_ss.png'></a>";}

$extension = substr($files, -4);


if ($extension == "sitx"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_sitx.png'></a>";}
if ($extension == "aiff"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_aiff.png'></a>";}
if ($extension == "divx"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_divx.png'></a>";}
if ($extension == "indd"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_indd.png'></a>";}
if ($extension == "mpeg"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_mpeg.png'></a>";}
if ($extension == "rmvb"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_rmvb.png'></a>";}

$extension = substr($files, -5);

if ($extension == "mswmm"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_mswmm.png'></a>";}


$extension = substr($files, -7);

if ($extension == "torrent"){echo "<a href='FILES/$files'><img src='TEMPLATES/fatcow_ext/file_extension_torrent.png'></a>";}



    }	

$x++;


if ($x > 20){die;}
}

}

}

}


//echo "</br>results : " . $x;


?>

</body>
</html>