MIT License.

- We don't responsibility for any damage or inadequate use.

	Templates by Bootstrap framework.

2020. 
enjoy

