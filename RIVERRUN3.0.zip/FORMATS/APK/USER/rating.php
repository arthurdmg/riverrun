﻿<html>
<head>

<link rel="stylesheet" type="text/css" href="default.css">

</head>

<body>

<?php


$i = 0;
$x = 0;



foreach (glob("LIKE/*") as $file){



foreach (glob("$file/*") as $file2){

$x++;




}

$exp = explode("/", $file2);


$filename = $exp[1];

if ($x >= 1 && $x < 10) {
$fp2 = fopen("RATING/10/$filename", "w");

fclose($fp2);
}


if ($x > 10 && $x < 100) {
$fp2 = fopen("RATING/100/$filename", "w");

fclose($fp2);
}


if ($x > 100 && $x < 1000) {
$fp2 = fopen("RATING/1000/$filename", "w");

fclose($fp2);
}


if ($x > 1000 && $x < 10000) {
$fp2 = fopen("RATING/10000/$filename", "w");

fclose($fp2);
}


if ($x > 10000 && $x < 100000) {
$fp2 = fopen("RATING/100000/$filename", "w");

fclose($fp2);
}


}



$total = 100;

echo "100000</br>";
foreach (glob("RATING/100000/*") as $files){
$exp2 = explode("/", $files);
$exp2 = $exp2[2];
echo "<a href='../FILES/$exp2'>$exp2</a></br>";

$i++;
if($i > $total){die;}
}

echo "10000</br>";
foreach (glob("RATING/10000/*") as $files){
$exp2 = explode("/", $files);
$exp2 = $exp2[2];
echo "<a href='../FILES/$exp2'>$exp2</a></br>";

$i++;
if($i > $total){die;}
}

echo "1000</br>";
foreach (glob("RATING/1000/*") as $files){
$exp2 = explode("/", $files);
$exp2 = $exp2[2];
echo "<a href='../FILES/$exp2'>$exp2</a></br>";

$i++;
if($i > $total){die;}
}

echo "100</br>";
foreach (glob("RATING/100/*") as $files){
$exp2 = explode("/", $files);
$exp2 = $exp2[2];
echo "<a href='../FILES/$exp2'>$exp2</a></br>";

$i++;
if($i > $total){die;}
}

echo "10</br>";
foreach (glob("RATING/10/*") as $files){
$exp2 = explode("/", $files);
$exp2 = $exp2[2];
echo "<a href='../FILES/$exp2'>$exp2</a></br>";

$i++;
if($i > $total){die;}
}

?>

</body>
</html>

