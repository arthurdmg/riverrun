<? session_start();
 $_SESSION['user'] = "";?>
<a href="../index.php"> Back</a>