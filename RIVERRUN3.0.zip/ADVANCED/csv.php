$list = array (
    array($name,$tag[1], $tag[2], $tag[3], $tag[4], $tag[5], $tag[6], $tag[7], $tag[8], $tag[9], $tag[10], $tag[11], $tag[12], $tag[13], $tag[14], $tag[15], $date),
);

$fp4 = fopen('ADVANCED/file.csv', 'a');

foreach ($list as $line) {
    fputcsv($fp4, $line);
}

fclose($fp4);
